(function(){
    console.log('Fed Classifieds assets loaded');
})();
